import os


PATH_TO_ROOT = os.path.dirname(__file__)
PATH_TO_CREDENTIALS = os.path.join(PATH_TO_ROOT, 'credentials.json')
