document.getElementById('year').innerHTML = new Date().getFullYear();
